Automation HAT
--------------


